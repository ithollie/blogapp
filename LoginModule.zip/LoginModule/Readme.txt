
HOW TO  RUN  THE  APPLICATION

php web  application.

0 Create a  folder call  webfolder in your desktop computer to host the  php  fillsX

1 Downlaod xampp or mamp  as  a  web server.

2 Open Xampp or  Mamp server and  start the server.

3 Create  an index.php or copy my fills  in  the  'xampp/htdocs' folder.

4 Make  sure  there is an  index.php file before starting the applciation.

5 Start  mysql server and  create a  database name  'users' and  In  the  database create fields  to  store  the

the  registration  data.

6 Access  the  application  by entering   to  the web  brower 'http://localhost/webfolder/index.php'.

7 Create  an  account  in  order  to  gain access  make  sure   all   input are  entered.

8 After creating an  account,  you can  go ahead a login.

